// Canvas setup
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Resize the canvas to match the screen size
function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

// Resize canvas initially and on window resize
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

let score = 0;
let player;
let bullets = [];
let enemyBullets = [];
let enemies = [];
let powerUps = [];
let enemySpawnInterval = 1000;
let lastEnemySpawnTime = 0;
let gameOver = false;
let doubleFire = false; // Track if power-up is active

// Load images
const playerImage = new Image();
playerImage.src = '/Users/salatonkariuki/Downloads/tinywow_change_bg_photo_67988594.png';
const enemyImage = new Image();
enemyImage.src = '/Users/salatonkariuki/Downloads/tinywow_change_bg_photo_67988629.png';
const playerBulletImage = new Image();
playerBulletImage.src = '/Users/salatonkariuki/Downloads/tinywow_change_bg_photo_67990217.png';
const enemyBulletImage = new Image();
enemyBulletImage.src = '/Users/salatonkariuki/Downloads/tinywow_change_bg_photo_67988668.png';
const powerUpImage = new Image();
powerUpImage.src = '/Users/salatonkariuki/Downloads/power_up.png';
const background = new Image();
background.src = '/Users/salatonkariuki/Downloads/background.png';

// Load sounds
const shootSound = new Audio('/Users/salatonkariuki/Downloads/shoot.mp3');
const hitSound = new Audio('/Users/salatonkariuki/Downloads/hit.mp3');

// Wait until all images are loaded before starting the game
const images = [playerImage, enemyImage, playerBulletImage, enemyBulletImage, powerUpImage, background];
let imagesLoaded = 0;
images.forEach((img) => {
    img.onload = () => {
        imagesLoaded++;
        if (imagesLoaded === images.length) {
            startGame();
        }
    };
});

// Player class
class Player {
    constructor() {
        this.width = 50;
        this.height = 50;
        this.x = canvas.width / 2 - this.width / 2;
        this.y = canvas.height - this.height - 10;
        this.speed = 7;
    }

    draw() {
        ctx.drawImage(playerImage, this.x, this.y, this.width, this.height);
    }

    move(direction) {
        this.x += direction * this.speed;
        if (this.x < 0) this.x = 0;
        if (this.x + this.width > canvas.width) this.x = canvas.width - this.width;
    }
}

// Bullet class
class Bullet {
    constructor(x, y, isEnemy = false) {
        this.x = x;
        this.y = y;
        this.width = 40; // Increased size for visibility
        this.height = 80; // Increased size for visibility
        this.speed = isEnemy ? 5 : 12;
        this.isEnemy = isEnemy;
    }

    draw() {
        ctx.drawImage(this.isEnemy ? enemyBulletImage : playerBulletImage, this.x, this.y, this.width, this.height);
    }

    update() {
        this.y += this.isEnemy ? this.speed : -this.speed;
    }
}

// Enemy class
class Enemy {
    constructor() {
        this.x = Math.random() * (canvas.width - 50);
        this.y = -50;
        this.width = 40;
        this.height = 50;
        this.speed = Math.random() * 2 + 1;
        this.lastShotTime = 0;
    }

    draw() {
        ctx.drawImage(enemyImage, this.x, this.y, this.width, this.height);
    }

    update() {
        this.y += this.speed;
    }

    shoot(timestamp) {
        if (timestamp - this.lastShotTime > 1500) {
            enemyBullets.push(new Bullet(this.x + this.width / 2 - 7.5, this.y + this.height, true));
            this.lastShotTime = timestamp;
        }
    }
}

// Power-up class
class PowerUp {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.width = 30;
        this.height = 30;
        this.speed = 3;
    }

    draw() {
        ctx.drawImage(powerUpImage, this.x, this.y, this.width, this.height);
    }

    update() {
        this.y += this.speed;
    }
}

// Initialize player
function startGame() {
    player = new Player();
    gameLoop();
}

// Handle keyboard controls
const keys = {};
document.addEventListener('keydown', (event) => {
    keys[event.code] = true;
    if (event.code === 'Space' && !gameOver) {
        if (doubleFire) {
            bullets.push(new Bullet(player.x + 5, player.y));
            bullets.push(new Bullet(player.x + player.width - 15, player.y));
        } else {
            bullets.push(new Bullet(player.x + player.width / 2 - 7.5, player.y));
        }
        shootSound.play(); // Play shooting sound
    }
});
document.addEventListener('keyup', (event) => {
    keys[event.code] = false;
});

// Update player position based on controls
function handlePlayerMovement() {
    if (keys['ArrowLeft']) {
        player.move(-1);
    }
    if (keys['ArrowRight']) {
        player.move(1);
    }
}

// Detect collisions for bullets hitting enemies and enemy bullets hitting player
function detectCollisions() {
    bullets.forEach((bullet, bulletIndex) => {
        enemies.forEach((enemy, enemyIndex) => {
            if (
                bullet.x < enemy.x + enemy.width &&
                bullet.x + bullet.width > enemy.x &&
                bullet.y < enemy.y + enemy.height &&
                bullet.y + bullet.height > enemy.y
            ) {
                bullets.splice(bulletIndex, 1); // Remove bullet
                enemies.splice(enemyIndex, 1); // Remove enemy
                score += 10;
                hitSound.play(); // Play hit sound
                console.log('Hit detected! Score:', score); // Debugging
            }
        });
    });

    // Check if enemy bullets hit the player
    enemyBullets.forEach((bullet, index) => {
        if (
            bullet.x < player.x + player.width &&
            bullet.x + bullet.width > player.x &&
            bullet.y < player.y + player.height &&
            bullet.y + bullet.height > player.y
        ) {
            gameOver = true;
            hitSound.play(); // Play hit sound
            console.log('Player hit! Game Over'); // Debugging
        }
    });
}

// Game loop
function gameLoop(timestamp) {
    if (gameOver) {
        displayGameOver();
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBackground(); // Draw background

    handlePlayerMovement();
    player.draw();

    bullets.forEach((bullet, index) => {
        bullet.update();
        bullet.draw();
        if (bullet.y < 0) bullets.splice(index, 1);
    });

    if (timestamp - lastEnemySpawnTime > enemySpawnInterval) {
        enemies.push(new Enemy());
        lastEnemySpawnTime = timestamp;
    }

    enemies.forEach((enemy, index) => {
        enemy.update();
        enemy.draw();
        enemy.shoot(timestamp);
        if (enemy.y > canvas.height) enemies.splice(index, 1);
    });

    enemyBullets.forEach((bullet, index) => {
        bullet.update();
        bullet.draw();
        if (bullet.y > canvas.height) enemyBullets.splice(index, 1);
    });

    detectCollisions(); // Check for collisions

    requestAnimationFrame(gameLoop);
}

    // Check if enemy bullets hit the player
    enemyBullets.forEach((bullet, index) => {
        if (
            bullet.x == player.x + player.width &&
            bullet.x + bullet.width == player.x &&
            bullet.y == player.y + player.height &&
            bullet.y + bullet.height == player.y
        ) {
            gameOver = true;
            hitSound.play(); // Play hit sound
        }
    });


// Draw the background covering the canvas
function drawBackground() {
    ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
}

// Game loop
function gameLoop(timestamp) {
    if (gameOver) {
        displayGameOver();
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBackground(); // Draw background

    handlePlayerMovement();
    player.draw();

    bullets.forEach((bullet, index) => {
        bullet.update();
        bullet.draw();
        if (bullet.y < 0) bullets.splice(index, 1);
    });

    if (timestamp - lastEnemySpawnTime > enemySpawnInterval) {
        enemies.push(new Enemy());
        lastEnemySpawnTime = timestamp;
    }

    enemies.forEach((enemy, index) => {
        enemy.update();
        enemy.draw();
        enemy.shoot(timestamp);
        if (enemy.y > canvas.height) enemies.splice(index, 1);
    });

    enemyBullets.forEach((bullet, index) => {
        bullet.update();
        bullet.draw();
        if (bullet.y > canvas.height) enemyBullets.splice(index, 1);
    });

    detectCollisions(); // Check for collisions

    requestAnimationFrame(gameLoop);
}

// Display game over screen
function displayGameOver() {
    ctx.fillStyle = 'white';
    ctx.font = '48px Arial';
    ctx.fillText('Game Over', canvas.width / 2 - 120, canvas.height / 2 - 20);
}